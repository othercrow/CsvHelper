CsvHelper won't work in Unity by default.
Drop this in Assets/Plugins or Assets/Editor/Plugins
